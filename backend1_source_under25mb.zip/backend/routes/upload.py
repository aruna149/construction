import logging
from pathlib import Path
from flask import Blueprint, request, jsonify
from utils.validators import validate_file
from services.file_service import FileService

# Initialize logger for route operations
logger = logging.getLogger(__name__)

# Register the blueprint
upload_bp = Blueprint('upload', __name__)

@upload_bp.route('/upload', methods=['POST'])
def upload_file():
    """Handle incoming PDF file uploads.
    
    Accepts multipart/form-data with a 'file' parameter.
    Validates file format, size, and type, and saves the file.
    
    Returns:
        JSON response with file metadata or error details.
    """
    logger.info("Upload started")
    
    # 1. Check if 'file' field exists in multipart request
    if 'file' not in request.files:
        logger.warning("Upload validation failed: Missing 'file' field in multipart request")
        return jsonify({
            "success": False,
            "message": "Missing file field in request."
        }), 400
        
    file = request.files['file']
    
    # 2. Check if the user submitted an empty field
    if not file or file.filename == '':
        logger.warning("Upload validation failed: No file selected")
        return jsonify({
            "success": False,
            "message": "No file selected."
        }), 400
        
    # 3. Perform detailed validation (extension, mimetype, size)
    is_valid, error_msg = validate_file(file)
    if not is_valid:
        logger.warning(f"Upload validation failed: {error_msg}")
        
        # Select appropriate status code
        # HTTP 413 Payload Too Large is returned for file size limit violations
        if "exceed" in error_msg:
            status_code = 413
        else:
            status_code = 400
            
        return jsonify({
            "success": False,
            "message": error_msg
        }), status_code
        
    # 4. Save file securely using FileService
    try:
        metadata = FileService.save_pdf(file)
        
        # Start PDF page splitting to PNG in the background immediately
        import threading
        from services.image_converter import ImageConverter
        from config import Config
        
        pdf_path = Path(Config.UPLOAD_FOLDER) / metadata['stored_name']
        doc_folder_name = metadata['stored_name'].rsplit('.', 1)[0]
        
        thread = threading.Thread(
            target=ImageConverter.convert_pdf_to_pngs,
            args=(str(pdf_path), doc_folder_name),
            daemon=True
        )
        thread.start()
        
        logger.info(f"Upload completed successfully. Stored as {metadata['stored_name']}")
        return jsonify({
            "success": True,
            "message": "File uploaded successfully.",
            "data": metadata
        }), 200
        
    except Exception as e:
        logger.exception("Unexpected exception occurred during PDF upload process")
        return jsonify({
            "success": False,
            "message": "An unexpected error occurred while saving the file."
        }), 500
