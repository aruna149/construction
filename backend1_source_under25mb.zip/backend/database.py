import sqlite3
import logging
from datetime import datetime
from config import Config

logger = logging.getLogger(__name__)

def get_db_connection():
    """Establish and return a connection to the SQLite database.
    
    Returns:
        sqlite3.Connection: The active database connection.
    """
    conn = sqlite3.connect(str(Config.DATABASE_FILE))
    # Return rows as dictionary-like objects instead of tuples
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Create the SQLite tables and insert default mock records if empty."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Create Dynamic Objects Table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS dynamic_objects (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                alias TEXT NOT NULL,
                description TEXT,
                image_path TEXT,
                status TEXT NOT NULL CHECK(status IN ('active', 'inactive')),
                last_updated TEXT NOT NULL
            )
        ''')
        conn.commit()
        pass
            
    except Exception as e:
        logger.exception("Failed to initialize or seed the database")
    finally:
        conn.close()
