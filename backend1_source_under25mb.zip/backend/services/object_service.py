import sqlite3
import logging
from typing import List, Dict, Any, Optional
from database import get_db_connection
from services.file_service import FileService

logger = logging.getLogger(__name__)

class ObjectService:
    """Service to handle SQLite Database CRUD operations for Dynamic Configurations."""
    
    @staticmethod
    def get_all(search_query: Optional[str] = None, status_filter: Optional[str] = None) -> List[Dict[str, Any]]:
        """Retrieve all dynamic configurations matching search and status criteria.
        
        Args:
            search_query: Optional string to match name or alias.
            status_filter: Optional string matching 'active' or 'inactive'.
            
        Returns:
            List[Dict[str, Any]]: List of objects.
        """
        conn = get_db_connection()
        cursor = conn.cursor()
        
        query = "SELECT * FROM dynamic_objects WHERE 1=1"
        params = []
        
        if search_query:
            query += " AND (name LIKE ? OR alias LIKE ?)"
            search_pattern = f"%{search_query}%"
            params.extend([search_pattern, search_pattern])
            
        if status_filter and status_filter in ('active', 'inactive'):
            query += " AND status = ?"
            params.append(status_filter)
            
        query += " ORDER BY last_updated DESC"
        
        try:
            cursor.execute(query, params)
            rows = cursor.fetchall()
            return [dict(row) for row in rows]
        except Exception:
            logger.exception("Failed to query objects from SQLite")
            return []
        finally:
            conn.close()

    @staticmethod
    def get_by_id(object_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve a single dynamic configuration details by its primary ID.
        
        Args:
            object_id: The primary key of the object.
            
        Returns:
            Optional[Dict[str, Any]]: The object if found, otherwise None.
        """
        conn = get_db_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute("SELECT * FROM dynamic_objects WHERE id = ?", (object_id,))
            row = cursor.fetchone()
            return dict(row) if row else None
        except Exception:
            logger.exception(f"Failed to query object with id: {object_id}")
            return None
        finally:
            conn.close()

    @staticmethod
    def create(object_id: str, name: str, alias: str, description: str, 
               image_path: str, status: str, last_updated: str) -> Optional[Dict[str, Any]]:
        """Insert a new dynamic configuration object.
        
        Args:
            object_id: Unique string ID.
            name: Display name.
            alias: System alias.
            description: Optional summary.
            image_path: Relative file path on server.
            status: 'active' or 'inactive'.
            last_updated: UTC ISO timestamp.
            
        Returns:
            Optional[Dict[str, Any]]: The created object dictionary, or None.
        """
        conn = get_db_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO dynamic_objects (id, name, alias, description, image_path, status, last_updated)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (object_id, name, alias, description, image_path, status, last_updated))
            conn.commit()
            
            return {
                "id": object_id,
                "name": name,
                "alias": alias,
                "description": description,
                "image_path": image_path,
                "status": status,
                "last_updated": last_updated
            }
        except Exception:
            logger.exception("Failed to insert new configuration row")
            return None
        finally:
            conn.close()

    @staticmethod
    def update(object_id: str, name: str, alias: str, description: str, 
               image_path: Optional[str], status: str, last_updated: str,
               image_removed: bool = False) -> Optional[Dict[str, Any]]:
        """Update an existing configuration.
        
        Args:
            object_id: Primary key of object.
            name: Display name.
            alias: System alias.
            description: Optional summary.
            image_path: Optional new image path on server.
            status: 'active' or 'inactive'.
            last_updated: UTC ISO timestamp.
            image_removed: If True, indicates user explicitly deleted the image.
            
        Returns:
            Optional[Dict[str, Any]]: The updated configuration, or None.
        """
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # 1. Fetch current object to check old image
        old_obj = ObjectService.get_by_id(object_id)
        if not old_obj:
            conn.close()
            return None
            
        old_image_path = old_obj.get("image_path")
        
        # Determine updated image path
        final_image_path = old_image_path
        if image_removed:
            final_image_path = ""
            if old_image_path:
                FileService.delete_image(old_image_path) # Delete old file
        elif image_path is not None:
            final_image_path = image_path
            if old_image_path:
                FileService.delete_image(old_image_path) # Delete old file
                
        try:
            cursor.execute('''
                UPDATE dynamic_objects
                SET name = ?, alias = ?, description = ?, image_path = ?, status = ?, last_updated = ?
                WHERE id = ?
            ''', (name, alias, description, final_image_path, status, last_updated, object_id))
            conn.commit()
            
            return {
                "id": object_id,
                "name": name,
                "alias": alias,
                "description": description,
                "image_path": final_image_path,
                "status": status,
                "last_updated": last_updated
            }
        except Exception:
            logger.exception(f"Failed to update configuration with ID: {object_id}")
            return None
        finally:
            conn.close()

    @staticmethod
    def delete(object_id: str) -> bool:
        """Remove a configuration row and delete its associated image from disk.
        
        Args:
            object_id: The primary key of the object to remove.
            
        Returns:
            bool: True if deleted successfully, False otherwise.
        """
        old_obj = ObjectService.get_by_id(object_id)
        if not old_obj:
            return False
            
        old_image_path = old_obj.get("image_path")
        if old_image_path:
            FileService.delete_image(old_image_path)
            
        conn = get_db_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute("DELETE FROM dynamic_objects WHERE id = ?", (object_id,))
            conn.commit()
            return cursor.rowcount > 0
        except Exception:
            logger.exception(f"Failed to delete configuration with ID: {object_id}")
            return False
        finally:
            conn.close()
