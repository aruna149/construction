import os
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, Any
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename
from config import Config

class FileService:
    """Service to handle directory creation, unique file naming, storage, and metadata extraction."""
    
    @staticmethod
    def save_pdf(file: FileStorage) -> Dict[str, Any]:
        """Save an uploaded PDF file, guaranteeing a unique UUID filename, and returning metadata.
        
        Args:
            file: The Werkzeug FileStorage object.
            
        Returns:
            Dict[str, Any]: A dictionary containing the file metadata.
        """
        # Ensure upload folder exists
        upload_path = Path(Config.UPLOAD_FOLDER)
        upload_path.mkdir(parents=True, exist_ok=True)
        
        # Get secure original filename
        original_name = secure_filename(file.filename or "unknown.pdf")
        
        # Generate a unique stored name using UUID
        # Use full UUID hex to prevent collision and preserve extensions
        unique_id = uuid.uuid4()
        stored_name = f"{unique_id}.pdf"
        
        target_file_path = upload_path / stored_name
        
        # In the extremely rare event that the file exists, loop until a unique one is found
        while target_file_path.exists():
            unique_id = uuid.uuid4()
            stored_name = f"{unique_id}.pdf"
            target_file_path = upload_path / stored_name
            
        # Get size
        file.seek(0, os.SEEK_END)
        size = file.tell()
        file.seek(0) # Reset stream pointer
        
        # Save the file
        file.save(str(target_file_path))
        
        # Formulate relative path for response
        relative_path = f"uploads/pdf/{stored_name}"
        
        # Capture current time in ISO format
        upload_time = datetime.utcnow().isoformat() + "Z"
        
        return {
            "original_name": original_name,
            "stored_name": stored_name,
            "size": size,
            "upload_time": upload_time,
            "path": relative_path
        }
        
    @staticmethod
    def save_image(file: FileStorage) -> str:
        """Save an uploaded image file, generating a unique UUID filename.
        
        Args:
            file: The Werkzeug FileStorage object.
            
        Returns:
            str: The relative path of the stored image, or empty string.
        """
        if not file or not file.filename:
            return ""
            
        # Ensure upload folder exists
        upload_path = Path(Config.IMAGE_UPLOAD_FOLDER)
        upload_path.mkdir(parents=True, exist_ok=True)
        
        # Get extension
        ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else 'png'
        
        # Generate unique name
        stored_name = f"{uuid.uuid4()}.{ext}"
        target_file_path = upload_path / stored_name
        
        # Save file
        file.save(str(target_file_path))
        
        # Return relative path (consistent with frontend loading)
        return f"uploads/images/{stored_name}"

    @staticmethod
    def delete_image(relative_path: str) -> None:
        """Delete an image file from disk if it exists.
        
        Args:
            relative_path: The relative path of the stored image.
        """
        if not relative_path:
            return
            
        # Extract the filename from relative path (e.g. 'uploads/images/xyz.png' -> 'xyz.png')
        filename = relative_path.split('/')[-1]
        
        # Resolve full path on server
        full_path = Path(Config.IMAGE_UPLOAD_FOLDER) / filename
        
        try:
            if full_path.exists() and full_path.is_file():
                full_path.unlink()
        except Exception as e:
            import logging
            logging.getLogger(__name__).warning(f"Failed to delete image from disk: {full_path}. Error: {e}")
