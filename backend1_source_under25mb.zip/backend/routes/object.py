import logging
import time
from datetime import datetime
from flask import Blueprint, request, jsonify
from config import Config
from services.object_service import ObjectService
from services.file_service import FileService

logger = logging.getLogger(__name__)

# Register Blueprint
object_bp = Blueprint('object', __name__)

def validate_image_upload(file) -> tuple[bool, str]:
    """Validate uploaded image file extension, content-type, and size.
    
    Args:
        file: Werkzeug FileStorage object.
        
    Returns:
        tuple[bool, str]: (is_valid, error_message)
    """
    if not file or not file.filename:
        return True, ""
        
    # Check extension
    if '.' not in file.filename:
        return False, "Image file must have an extension."
    ext = file.filename.rsplit('.', 1)[1].lower()
    if ext not in Config.ALLOWED_IMAGE_EXTENSIONS:
        return False, f"Format '.{ext}' not allowed. Use JPG, JPEG, PNG, or WEBP."
        
    # Check mime type
    if file.content_type not in Config.ALLOWED_IMAGE_MIMETYPES:
        return False, "Invalid image type. Supported formats: JPG, JPEG, PNG, WEBP."
        
    # Check size (max 5 MB)
    try:
        file.seek(0, 2) # Seek to end
        size = file.tell()
        file.seek(0) # Reset stream pointer
        
        if size > Config.MAX_IMAGE_SIZE:
            return False, "Image size exceeds the 5 MB limit."
    except Exception:
        return False, "Failed to determine image size."
        
    return True, ""

@object_bp.route('/objects', methods=['GET'])
def get_objects():
    """Retrieve filtered dynamic objects list.
    
    Query Params:
        search: Optional search key.
        status: Optional status filter.
    """
    search_query = request.args.get('search')
    status_filter = request.args.get('status')
    
    objects = ObjectService.get_all(search_query, status_filter)
    return jsonify({
        "success": True,
        "data": objects
    }), 200

@object_bp.route('/objects/<object_id>', methods=['GET'])
def get_object(object_id):
    """Retrieve details for a single dynamic configuration."""
    obj = ObjectService.get_by_id(object_id)
    if not obj:
        return jsonify({
            "success": False,
            "message": "Object not found."
        }), 404
        
    return jsonify({
        "success": True,
        "data": obj
    }), 200

@object_bp.route('/objects', methods=['POST'])
def create_object():
    """Create a new dynamic configuration object.
    
    Accepts multipart/form-data.
    """
    name = request.form.get('name')
    alias = request.form.get('alias')
    description = request.form.get('description', '')
    status = request.form.get('status', 'active')
    
    # 1. Required fields check
    if not name or not alias:
        return jsonify({
            "success": False,
            "message": "Object Name and Alias Name are required fields."
        }), 400
        
    if status not in ('active', 'inactive'):
        return jsonify({
            "success": False,
            "message": "Invalid status value. Must be 'active' or 'inactive'."
        }), 400

    # 2. Image upload check
    image_file = request.files.get('image')
    if image_file and image_file.filename != '':
        is_valid, err_msg = validate_image_upload(image_file)
        if not is_valid:
            return jsonify({
                "success": False,
                "message": err_msg
            }), 400
            
        # Save image
        try:
            image_path = FileService.save_image(image_file)
        except Exception:
            logger.exception("Failed to save uploaded image file")
            return jsonify({
                "success": False,
                "message": "Failed to save uploaded image asset."
            }), 500
    else:
        image_path = ""

    # 3. Create database row
    obj_id = f"obj-{int(time.time() * 1000)}" # Unique milisecond timestamp ID
    last_updated = datetime.utcnow().isoformat() + "Z"
    
    result = ObjectService.create(obj_id, name, alias, description, image_path, status, last_updated)
    if not result:
        # Cleanup image file if row creation failed
        if image_path:
            FileService.delete_image(image_path)
        return jsonify({
            "success": False,
            "message": "Database insertion failed."
        }), 500
        
    logger.info(f"Successfully created dynamic object {name} ({obj_id})")
    return jsonify({
        "success": True,
        "message": "Object created successfully.",
        "data": result
    }), 201

@object_bp.route('/objects/<object_id>', methods=['PUT'])
def update_object(object_id):
    """Update an existing configuration profile.
    
    Accepts multipart/form-data.
    """
    name = request.form.get('name')
    alias = request.form.get('alias')
    description = request.form.get('description', '')
    status = request.form.get('status', 'active')
    image_removed_flag = request.form.get('image_removed') == 'true'
    
    # 1. Check if object exists
    existing = ObjectService.get_by_id(object_id)
    if not existing:
        return jsonify({
            "success": False,
            "message": "Object not found."
        }), 404

    # 2. Required fields check
    if not name or not alias:
        return jsonify({
            "success": False,
            "message": "Object Name and Alias Name are required fields."
        }), 400
        
    if status not in ('active', 'inactive'):
        return jsonify({
            "success": False,
            "message": "Invalid status value. Must be 'active' or 'inactive'."
        }), 400

    # 3. Image validation and upload check
    image_file = request.files.get('image')
    image_path = None
    
    if image_file and image_file.filename != '':
        is_valid, err_msg = validate_image_upload(image_file)
        if not is_valid:
            return jsonify({
                "success": False,
                "message": err_msg
            }), 400
            
        try:
            image_path = FileService.save_image(image_file)
        except Exception:
            logger.exception("Failed to save updated image file")
            return jsonify({
                "success": False,
                "message": "Failed to save updated image asset."
            }), 500

    # 4. Update database row
    last_updated = datetime.utcnow().isoformat() + "Z"
    
    result = ObjectService.update(
        object_id=object_id,
        name=name,
        alias=alias,
        description=description,
        image_path=image_path,
        status=status,
        last_updated=last_updated,
        image_removed=image_removed_flag
    )
    
    if not result:
        # Cleanup new image if update failed
        if image_path:
            FileService.delete_image(image_path)
        return jsonify({
            "success": False,
            "message": "Database update failed."
        }), 500
        
    logger.info(f"Successfully updated dynamic object {name} ({object_id})")
    return jsonify({
        "success": True,
        "message": "Object updated successfully.",
        "data": result
    }), 200

@object_bp.route('/objects/<object_id>', methods=['DELETE'])
def delete_object(object_id):
    """Delete a configuration object and its images."""
    if not ObjectService.get_by_id(object_id):
        return jsonify({
            "success": False,
            "message": "Object not found."
        }), 404
        
    success = ObjectService.delete(object_id)
    if not success:
        return jsonify({
            "success": False,
            "message": "Database deletion failed."
        }), 500
        
    logger.info(f"Successfully deleted dynamic object ({object_id})")
    return jsonify({
        "success": True,
        "message": "Object deleted successfully."
    }), 200
