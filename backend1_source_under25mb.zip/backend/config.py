import os
from pathlib import Path

class Config:
    """Flask application configuration class."""
    # Resolve backend project root directory
    BASE_DIR = Path(__file__).resolve().parent
    
    # Secret key for Flask application security
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-key-pdf-upload-app-2026')
    
    # Directory where uploaded files will be stored
    UPLOAD_FOLDER = BASE_DIR / 'uploads' / 'pdf'
    
    # Database file location (SQLite)
    DATABASE_FILE = BASE_DIR / 'database.db'
    
    # Directory where uploaded images will be stored
    IMAGE_UPLOAD_FOLDER = BASE_DIR / 'uploads' / 'images'
    
    # Directory where processed PDF page images will be stored
    PROCESSED_FOLDER = BASE_DIR / 'processed'
    
    # Limit maximum file upload size to 100 MB (100 * 1024 * 1024 bytes)
    MAX_CONTENT_LENGTH = 100 * 1024 * 1024
    
    # Max size for image configuration uploads (5 MB)
    MAX_IMAGE_SIZE = 5 * 1024 * 1024
    
    # Allowed file extensions
    ALLOWED_EXTENSIONS = {'pdf'}
    
    # Allowed mimetypes
    ALLOWED_MIMETYPES = {'application/pdf'}
    
    # Allowed image file parameters
    ALLOWED_IMAGE_EXTENSIONS = {'jpg', 'jpeg', 'png', 'webp'}
    ALLOWED_IMAGE_MIMETYPES = {'image/jpeg', 'image/png', 'image/webp'}
    
    # CORS Allowed Origins
    CORS_ORIGINS = os.environ.get(
        'CORS_ORIGINS', 
        'http://localhost:5500,http://127.0.0.1:5500,null'
    ).split(',')

    # LandingLens Credentials
    LANDINGAI_API_KEY = os.environ.get('LANDINGAI_API_KEY', 'land_sk_8Kz9amh3FdBHEsYnixTjwp1aEjkNWMJuboi5Rr3i3eVET7WnMh')
    LANDINGAI_ENDPOINT_ID = os.environ.get('LANDINGAI_ENDPOINT_ID', 'b36ba14d-6e8a-44e4-98ce-6ea01d110f0c')
