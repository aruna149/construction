# PDF Upload Backend API

A secure, modular, production-ready Flask backend that validates, logs, and stores uploaded PDF documents.

## Project Structure

```
backend/
├── app.py                  # Application entry point & configuration loader
├── config.py               # Configurable parameters (paths, sizes, keys, CORS)
├── requirements.txt        # Backend dependencies
├── routes/
│   └── upload.py           # Blueprint and route handler for /api/upload
├── services/
│   └── file_service.py     # Unique filename generation & file storage logic
├── utils/
│   └── validators.py       # Reusable extension, mimetype, and size validators
├── uploads/
│   └── pdf/                # PDF files storage directory
├── logs/
│   └── app.log             # Rotating application log file
└── README.md               # Setup and API documentation
```

---

## Prerequisites

- Python 3.12+ (or compatible 3.x)
- pip (Python package installer)

---

## Installation & Setup

1. **Navigate to the backend directory**:
   ```bash
   cd backend
   ```

2. **Create a virtual environment**:
   - On Windows:
     ```bash
     python -m venv venv
     ```
   - On macOS/Linux:
     ```bash
     python3 -m venv venv
     ```

3. **Activate the virtual environment**:
   - On Windows (PowerShell):
     ```powershell
     .\venv\Scripts\Activate.ps1
     ```
   - On Windows (Command Prompt):
     ```cmd
     .\venv\Scripts\activate.bat
     ```
   - On macOS/Linux:
     ```bash
     source venv/bin/activate
     ```

4. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

---

## Running the Server

Start the development server using:
```bash
python app.py
```
By default, the server runs on `http://localhost:5000` with hot-reloading enabled.

### Optional local Docling extraction

The results page includes a **Local Docling** tab for OCR and document-layout extraction. It is optional and does not replace the existing browser analysis or LandingAI ADE. The uploaded PDF is sent to this Flask backend; Docling processes it locally. On first use, Docling may download its model files.

Install the optional dependencies in the backend environment and restart Flask:

```powershell
.\venv\Scripts\Activate.ps1
pip install -r requirements-docling.txt
python app.py
```

The frontend uses `http://127.0.0.1:5000/api/docling` by default. Change the endpoint in the Local Docling tab if the backend is running elsewhere. Docling accepts one extraction at a time to limit memory use; its Markdown output is available to copy or download. Results are an extraction aid, not an authoritative structural-engineering interpretation.

---

## API Documentation

### Upload PDF File

Upload a PDF file using multipart form-data.

- **URL**: `/api/upload`
- **Method**: `POST`
- **Content-Type**: `multipart/form-data`
- **Headers**:
  - `Origin` (optional, for CORS checking): Match configured CORS origins (e.g. `http://localhost:5500`).
- **Body Parameters**:
  - `file`: The binary PDF file to upload (required).

#### Example Request using `curl`:
```bash
curl -X POST -F "file=@/path/to/document.pdf" http://127.0.0.1:5000/api/upload
```

#### Example Successful Response (HTTP 200 OK):
```json
{
  "success": true,
  "message": "File uploaded successfully.",
  "data": {
    "original_name": "document.pdf",
    "stored_name": "8b5f3a09-7d8b-4a54-a6b1-dfc7db8e100f.pdf",
    "size": 142054,
    "upload_time": "2026-07-03T12:18:00.123456Z",
    "path": "uploads/pdf/8b5f3a09-7d8b-4a54-a6b1-dfc7db8e100f.pdf"
  }
}
```

#### Example Validation Error Responses:

- **Invalid Extension / MIME Type (HTTP 400 Bad Request)**:
  ```json
  {
    "success": false,
    "message": "Only PDF files are allowed."
  }
  ```

- **File Too Large / Empty File (HTTP 413 Payload Too Large)**:
  ```json
  {
    "success": false,
    "message": "File must not be empty and cannot exceed 25 MB."
  }
  ```

- **No File Selected (HTTP 400 Bad Request)**:
  ```json
  {
    "success": false,
    "message": "No file selected."
  }
  ```

---

## Security Implementation

1. **Path Traversal Protection**: Leverages Werkzeug's `secure_filename` to sanitize incoming original filenames.
2. **UUID Unique Storing**: Standardizes file storage names using standard `uuid.uuid4()` to hide and guard original filenames, preventing file-overwrite vulnerabilities.
3. **MIME Type Checking**: Validates both file extensions (`.pdf`) and headers (`application/pdf`) to guard against header spoofing.
4. **CORS Control**: Restricts cross-origin requests to configured domains only.
5. **Strict File Size Limits**: Leverages both Flask's `MAX_CONTENT_LENGTH` and custom validator checking to block large body resource exhaustion attacks.
