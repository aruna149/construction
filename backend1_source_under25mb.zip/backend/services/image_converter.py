import fitz  # PyMuPDF
import logging
import threading
import time
import os
from pathlib import Path
from typing import List
from PIL import Image
from config import Config

logger = logging.getLogger(__name__)

# Global registry to serialize rendering of the same document across threads
rendering_lock = threading.Lock()
active_renders = set()

class ImageConverter:
    """Service to render PDF document pages into high-resolution PNG images."""
    
    # Configuration Constants for AI Optimization
    MAX_IMAGE_DIMENSION = 2800  # Target longest side (between 2500-3000)
    MAX_FILE_SIZE_KB = 1500     # 1.5 MB limit
    RENDER_DPI_ATTEMPTS = [150, 72, 36]  # Fallback chain for rendering
    PNG_OPTIMIZE = True
    
    @staticmethod
    def convert_pdf_to_pngs(pdf_path: str, document_name: str) -> List[str]:
        """Convert all pages of a PDF into high-res PNGs and store them.
        
        Args:
            pdf_path: Path to the uploaded PDF.
            document_name: Subfolder name for the processed outputs (usually PDF name without extension).
            
        Returns:
            List[str]: List of relative paths (e.g. 'processed/<document_name>/page_001.png') for the saved files.
        """
        pdf_path_obj = Path(pdf_path)
        if not pdf_path_obj.exists():
            logger.error(f"PDF file does not exist: {pdf_path}")
            return []
            
        # Serialize duplicate render requests (e.g. if background thread is still running)
        is_owner = False
        while True:
            with rendering_lock:
                if document_name not in active_renders:
                    active_renders.add(document_name)
                    is_owner = True
                    break
                else:
                    logger.info(f"Document {document_name} is already rendering in another thread. Waiting...")
            time.sleep(0.5)

        try:
            # 1. Check if files are already generated and match total PDF pages
            try:
                doc = fitz.open(str(pdf_path_obj))
                expected_pages = len(doc)
                doc.close()
            except Exception:
                expected_pages = 0
                
            target_dir = Path(Config.PROCESSED_FOLDER) / document_name
            existing_pngs = sorted(list(target_dir.glob('page_*.png'))) if target_dir.exists() else []
            
            if expected_pages > 0 and len(existing_pngs) == expected_pages:
                logger.info(f"Page PNGs already fully generated for {document_name}. Skipping render.")
                return [f"processed/{document_name}/{p.name}" for p in existing_pngs]

            # 2. Re-create processed subdirectory
            target_dir.mkdir(parents=True, exist_ok=True)
            
            saved_paths = []
            logger.info(f"Opening PDF for processing: {pdf_path_obj.name}")
            doc = fitz.open(str(pdf_path_obj))
            
            for page_idx in range(len(doc)):
                start_time = time.time()
                page = doc.load_page(page_idx)
                page_num = page_idx + 1
                
                # Fallback mechanism to prevent Out Of Memory (OOM) crashes on massive blueprints
                pix = None
                rendered_dpi = None
                for attempt_dpi in ImageConverter.RENDER_DPI_ATTEMPTS:
                    try:
                        dpi_factor = attempt_dpi / 72.0
                        matrix = fitz.Matrix(dpi_factor, dpi_factor)
                        pix = page.get_pixmap(matrix=matrix)
                        rendered_dpi = attempt_dpi
                        if attempt_dpi != ImageConverter.RENDER_DPI_ATTEMPTS[0]:
                            logger.warning(f"Fell back to {attempt_dpi} DPI for page {page_num} to prevent OOM crash.")
                        break
                    except Exception as e:
                        logger.warning(f"Failed to render page {page_num} at {attempt_dpi} DPI: {e}. Trying lower resolution...")
                        
                if pix is None:
                    raise RuntimeError(f"Could not render page {page_num} even at lowest DPI due to memory limits.")
                
                original_width = pix.width
                original_height = pix.height
                
                # Format page filename with leading zeros (1-indexed for frontend compatibility)
                filename = f"page_{page_num:03d}.png"
                target_file_path = target_dir / filename
                
                # Convert fitz pixmap to PIL Image for high-quality resizing and optimization
                mode = "RGBA" if pix.alpha else "RGB"
                img = Image.frombytes(mode, [pix.width, pix.height], pix.samples)
                
                # Release the PyMuPDF pixmap from memory early
                pix = None
                
                current_max_dim = ImageConverter.MAX_IMAGE_DIMENSION
                
                # Iteratively reduce size and save until the file size limit is met
                while True:
                    # Resize using a high-quality resampling algorithm (LANCZOS)
                    # thumbnail maintains aspect ratio and modifies in-place
                    img.thumbnail((current_max_dim, current_max_dim), Image.Resampling.LANCZOS)
                    
                    # Save as an optimized PNG
                    img.save(str(target_file_path), "PNG", optimize=ImageConverter.PNG_OPTIMIZE)
                    file_size_kb = os.path.getsize(str(target_file_path)) / 1024
                    
                    # Stop if we are under the file size limit, or if the image is getting too small
                    if file_size_kb <= ImageConverter.MAX_FILE_SIZE_KB or current_max_dim <= 800:
                        break
                        
                    # Reduce dimensions by 15% and try again to fit the file size limit
                    current_max_dim = int(current_max_dim * 0.85)
                
                resized_width = img.width
                resized_height = img.height
                
                # Release PIL image memory
                img.close()
                img = None
                processing_time = time.time() - start_time
                
                logger.info(
                    f"Processed {filename} - "
                    f"Original: {original_width}x{original_height} (DPI: {rendered_dpi}), "
                    f"Resized: {resized_width}x{resized_height}, "
                    f"File size: {file_size_kb:.2f} KB, "
                    f"Time: {processing_time:.2f}s"
                )
                
                # Construct relative path string for API response
                relative_path = f"processed/{document_name}/{filename}"
                saved_paths.append(relative_path)
                
            doc.close()
            logger.info(f"Completed converting PDF '{pdf_path_obj.name}' ({len(saved_paths)} pages)")
            return saved_paths
            
        except Exception:
            logger.exception(f"Failed to convert PDF pages to PNG for file: {pdf_path_obj.name}")
            return []
        finally:
            with rendering_lock:
                if is_owner and document_name in active_renders:
                    active_renders.remove(document_name)
