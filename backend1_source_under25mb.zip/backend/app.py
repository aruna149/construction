import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from flask import Flask, jsonify, send_from_directory
from flask_cors import CORS
from werkzeug.exceptions import HTTPException
from config import Config
from database import init_db
from routes.upload import upload_bp
from routes.object import object_bp
from routes.analysis import analysis_bp
from routes.docling import docling_bp

def configure_logging(app: Flask) -> None:
    """Setup application logging to file and standard stream."""
    log_dir = Path(__file__).resolve().parent / 'logs'
    log_dir.mkdir(exist_ok=True)
    
    log_file = log_dir / 'app.log'
    
    # Standard format for logs
    log_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Use Rotating File Handler to limit file size
    file_handler = RotatingFileHandler(
        log_file, 
        maxBytes=5 * 1024 * 1024,  # 5MB
        backupCount=3
    )
    file_handler.setFormatter(log_formatter)
    file_handler.setLevel(logging.INFO)
    
    # Configure root logger and Flask's logger
    logging.getLogger().setLevel(logging.INFO)
    logging.getLogger().addHandler(file_handler)
    app.logger.addHandler(file_handler)

def create_app() -> Flask:
    """Factory function to build and configure the Flask application."""
    app = Flask(__name__)
    
    # Load configuration parameters
    app.config.from_object(Config)
    
    # Initialize CORS
    # Allow request routing for standard APIs and asset loading
    CORS(app, resources={
        r"/api/*": {"origins": Config.CORS_ORIGINS},
        r"/uploads/*": {"origins": Config.CORS_ORIGINS},
        r"/processed/*": {"origins": Config.CORS_ORIGINS}
    })
    
    # Set up logs
    configure_logging(app)
    
    # Initialize SQLite Database tables
    init_db()
    
    # Register blueprints
    app.register_blueprint(upload_bp, url_prefix='/api')
    app.register_blueprint(object_bp, url_prefix='/api')
    app.register_blueprint(analysis_bp, url_prefix='/api')
    app.register_blueprint(docling_bp, url_prefix='/api')
    
    # Dynamic static files serving for uploaded assets
    @app.route('/uploads/<path:filename>')
    def serve_uploads(filename):
        return send_from_directory(Config.BASE_DIR / 'uploads', filename)

    # Dynamic static files serving for processed PDF pages
    @app.route('/processed/<path:filename>')
    def serve_processed(filename):
        return send_from_directory(Config.BASE_DIR / 'processed', filename)
    
    # ==========================================
    # Global Error Handlers
    # ==========================================
    
    @app.errorhandler(HTTPException)
    def handle_http_exception(e: HTTPException):
        """Converts standard HTTP errors (like 400, 404, 413) to JSON responses."""
        app.logger.warning(f"HTTP exception occurred: {e.code} - {e.description}")
        return jsonify({
            "success": False,
            "message": e.description or "A client-side error occurred."
        }), e.code
        
    @app.errorhandler(Exception)
    def handle_unexpected_exception(e: Exception):
        """Converts unexpected server errors to a generic JSON response and logs stacktrace."""
        app.logger.exception("An unhandled exception occurred within the application")
        return jsonify({
            "success": False,
            "message": "An unexpected server error occurred."
        }), 500
        
    return app

# Expose app for deployment or standard execution
app = create_app()

if __name__ == '__main__':
    # Start the local development server
    app.run(host='0.0.0.0', port=5000, debug=True)
