import os
from typing import Tuple
from werkzeug.datastructures import FileStorage
from config import Config

def allowed_file(filename: str) -> bool:
    """Check if the file has an allowed PDF extension.
    
    Args:
        filename: The original name of the file.
        
    Returns:
        bool: True if the file extension is allowed, False otherwise.
    """
    if not filename or '.' not in filename:
        return False
    ext = filename.rsplit('.', 1)[1].lower()
    return ext in Config.ALLOWED_EXTENSIONS

def validate_mimetype(mimetype: str) -> bool:
    """Validate that the file's MIME type is application/pdf.
    
    Args:
        mimetype: The content type/mimetype of the uploaded file.
        
    Returns:
        bool: True if allowed, False otherwise.
    """
    return mimetype in Config.ALLOWED_MIMETYPES

def validate_size(file: FileStorage) -> bool:
    """Validate that the file size is non-empty and within the configured limit.
    
    Args:
        file: The Werkzeug FileStorage object.
        
    Returns:
        bool: True if valid size, False otherwise.
    """
    try:
        # Seek to the end of the file to determine size
        file.seek(0, os.SEEK_END)
        size = file.tell()
        # Reset file pointer back to start
        file.seek(0)
        
        # Check if empty or too large
        return 0 < size <= Config.MAX_CONTENT_LENGTH
    except Exception:
        return False

def validate_file(file: FileStorage) -> Tuple[bool, str]:
    """Perform all validation checks on the uploaded file.
    
    Args:
        file: The Werkzeug FileStorage object to validate.
        
    Returns:
        Tuple[bool, str]: (is_valid, error_message)
    """
    if not file or not file.filename:
        return False, "No file selected or uploaded."
        
    if not allowed_file(file.filename):
        return False, "Only PDF files are allowed."
        
    if not validate_mimetype(file.content_type):
        return False, "Invalid file type. Only PDF files are allowed."
        
    if not validate_size(file):
        return False, "File must not be empty and cannot exceed 25 MB."
        
    return True, ""
