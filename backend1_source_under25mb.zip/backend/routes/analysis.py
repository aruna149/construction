import logging
from pathlib import Path
from flask import Blueprint, request, jsonify, send_from_directory
from config import Config
from services.detection_service import DetectionService, results_store

logger = logging.getLogger(__name__)

# Register Blueprint
analysis_bp = Blueprint('analysis', __name__)

@analysis_bp.route('/analysis/start', methods=['POST'])
def start_analysis():
    """Start asynchronous PDF page rendering and object detection.
    
    Accepts application/json or multipart/form-data.
    """
    # 1. Extract document_id
    document_id = None
    if request.is_json:
        data = request.get_json()
        document_id = data.get('document_id')
    else:
        document_id = request.form.get('document_id')
        
    if not document_id:
        return jsonify({
            "success": False,
            "message": "Missing 'document_id' in request parameter."
        }), 400

    # 2. Check if file exists in PDF uploads folder
    pdf_path = Path(Config.BASE_DIR) / 'uploads' / 'pdf' / document_id
    if not pdf_path.exists():
        return jsonify({
            "success": False,
            "message": f"Uploaded PDF file '{document_id}' not found."
        }), 404

    # 3. Start async job thread
    try:
        job_id = DetectionService.start_analysis(document_id)
        return jsonify({
            "success": True,
            "message": "Analysis job started successfully.",
            "data": {
                "job_id": job_id
            }
        }), 202
    except Exception as e:
        logger.exception("Failed to initiate async analysis job")
        return jsonify({
            "success": False,
            "message": "An unexpected error occurred while starting analysis."
        }), 500

@analysis_bp.route('/analysis/status/<job_id>', methods=['GET'])
def get_analysis_status(job_id):
    """Retrieve current progression details of an analysis thread."""
    status_data = DetectionService.get_job_status(job_id)
    if not status_data:
        return jsonify({
            "success": False,
            "message": "Analysis job not found."
        }), 404
        
    return jsonify({
        "success": True,
        "data": status_data
    }), 200

@analysis_bp.route('/analysis/results/<document_id>', methods=['GET'])
def get_analysis_results(document_id):
    """Retrieve completed detection array results for a document."""
    results = DetectionService.get_document_results(document_id)
    if not results:
        return jsonify({
            "success": False,
            "message": "No analysis results found for this document."
        }), 404
        
    return jsonify({
        "success": True,
        "data": results
    }), 200

@analysis_bp.route('/analysis/page/<document_id>/<int:page_number>', methods=['GET'])
def get_analysis_page(document_id, page_number):
    """Serve the rendered PNG page image for the page index."""
    # Convert pdf name to folder name (e.g. 'building.pdf' -> 'building')
    doc_folder_name = document_id.rsplit('.', 1)[0]
    filename = f"page_{page_number:03d}.png"
    
    # Check if page file exists on disk
    target_dir = Path(Config.PROCESSED_FOLDER) / doc_folder_name
    target_file = target_dir / filename
    
    if not target_file.exists():
        return jsonify({
            "success": False,
            "message": f"Processed page {page_number} image not found."
        }), 404
        
    return send_from_directory(str(target_dir), filename)

@analysis_bp.route('/analysis/highlight/<detection_id>', methods=['GET'])
def get_detection_highlight(detection_id):
    """Retrieve bounding box mapping coordinates for a specific detection."""
    # Iterate through completed results store to locate detection
    found_detection = None
    
    for doc_id, result_data in results_store.items():
        for det in result_data.get("detections", []):
            if det.get("detection_id") == detection_id:
                found_detection = det
                break
        if found_detection:
            break
            
    if not found_detection:
        return jsonify({
            "success": False,
            "message": "Detection ID not found."
        }), 404
        
    return jsonify({
        "success": True,
        "data": found_detection
    }), 200
