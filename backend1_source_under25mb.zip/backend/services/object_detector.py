import logging
import uuid
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

import cv2
import numpy as np

from config import Config

logger = logging.getLogger(__name__)


class ObjectDetector:
    """Template-based detector for blueprint symbols.

    Each configured object includes a reference image. We scan every page and
    match those symbols using OpenCV template matching.
    """

    @staticmethod
    def _read_gray_image(file_path: Path) -> np.ndarray | None:
        """Load a grayscale image, returning None if the file does not exist."""
        if not file_path.exists():
            return None
        image = cv2.imread(str(file_path), cv2.IMREAD_GRAYSCALE)
        return image

    @staticmethod
    def _match_object(
        page_gray: np.ndarray,
        template_gray: np.ndarray,
        object_name: str,
        object_id: str,
        page_number: int,
        score_threshold: float = 0.30,
    ) -> List[Dict[str, Any]]:
        """Return all high-confidence detections for one object on one page."""
        if template_gray.size == 0 or page_gray.size == 0:
            return []

        result = cv2.matchTemplate(page_gray, template_gray, cv2.TM_CCOEFF_NORMED)
        detections: List[Dict[str, Any]] = []
        mask = result.copy()

        while True:
            _, max_val, _, max_loc = cv2.minMaxLoc(mask)
            if max_val < score_threshold:
                break

            left, top = max_loc
            template_h, template_w = template_gray.shape
            right = left + template_w
            bottom = top + template_h

            # Remove the matched area so multiple nearby duplicates are not counted
            cv2.rectangle(mask, (left, top), (right, bottom), 0.0, -1)

            detections.append({
                "detection_id": str(uuid.uuid4()),
                "object_id": object_id,
                "name": object_name,
                "page": page_number,
                "bbox": {
                    "x": int(left),
                    "y": int(top),
                    "width": int(template_w),
                    "height": int(template_h),
                },
                "confidence": float(max_val),
            })

        return detections

    @staticmethod
    def detect_objects(
        page_image_path: str,
        active_objects: Sequence[Dict[str, Any]],
        page_number: int,
    ) -> List[Dict[str, Any]]:
        """Scan one blueprint page against the configured active object templates."""
        if not page_image_path:
            return []

        page_path = Path(Config.BASE_DIR) / page_image_path
        page_gray = ObjectDetector._read_gray_image(page_path)
        if page_gray is None:
            logger.warning("Page image not found for detection: %s", page_image_path)
            return []

        all_detections: List[Dict[str, Any]] = []

        for obj in active_objects or []:
            image_path = obj.get("image_path")
            if not image_path:
                continue

            template_path = Path(Config.BASE_DIR) / image_path
            template_gray = ObjectDetector._read_gray_image(template_path)
            if template_gray is None:
                continue

            try:
                matched = ObjectDetector._match_object(
                    page_gray=page_gray,
                    template_gray=template_gray,
                    object_name=obj.get("name") or obj.get("alias") or "object",
                    object_id=str(obj.get("id") or "unknown-object"),
                    page_number=page_number,
                )
                all_detections.extend(matched)
            except Exception:
                logger.exception("Failed to match object %s on page %s", obj.get("id"), page_number)

        logger.info("Detected %s objects on page %s", len(all_detections), page_number)
        return all_detections
