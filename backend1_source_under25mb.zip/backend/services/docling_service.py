import logging
import threading
import uuid
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)
_jobs: Dict[str, Dict[str, Any]] = {}
_jobs_lock = threading.Lock()
_worker_slot = threading.BoundedSemaphore(1)


class DoclingBusyError(RuntimeError):
    """Raised when a local Docling extraction is already running."""


class DoclingService:
    """Run one memory-intensive Docling PDF conversion at a time."""

    @staticmethod
    def start_job(pdf_path: Path) -> str:
        if not _worker_slot.acquire(blocking=False):
            raise DoclingBusyError(
                "A Docling extraction is already running. Wait for it to finish and retry."
            )

        job_id = str(uuid.uuid4())
        with _jobs_lock:
            _jobs.clear()
            _jobs[job_id] = {
                "job_id": job_id,
                "status": "pending",
                "result": None,
                "error": None
            }

        worker = threading.Thread(
            target=DoclingService._run_job,
            args=(job_id, pdf_path),
            daemon=True
        )
        try:
            worker.start()
        except Exception:
            with _jobs_lock:
                _jobs.pop(job_id, None)
            _worker_slot.release()
            raise
        return job_id

    @staticmethod
    def get_job(job_id: str) -> Optional[Dict[str, Any]]:
        with _jobs_lock:
            job = _jobs.get(job_id)
            return dict(job) if job is not None else None

    @staticmethod
    def _run_job(job_id: str, pdf_path: Path) -> None:
        with _jobs_lock:
            _jobs[job_id]["status"] = "running"

        try:
            from docling.datamodel.base_models import InputFormat
            from docling.datamodel.pipeline_options import PdfPipelineOptions
            from docling.document_converter import DocumentConverter, PdfFormatOption

            pipeline_options = PdfPipelineOptions()
            pipeline_options.do_ocr = True
            pipeline_options.do_table_structure = True
            converter = DocumentConverter(
                format_options={
                    InputFormat.PDF: PdfFormatOption(pipeline_options=pipeline_options)
                }
            )
            document = converter.convert(str(pdf_path)).document
            result = {
                "markdown": document.export_to_markdown(),
                "page_count": len(document.pages)
            }
            with _jobs_lock:
                _jobs[job_id].update(status="completed", result=result)
        except Exception as error:
            logger.exception("Docling extraction job %s failed", job_id)
            with _jobs_lock:
                _jobs[job_id].update(status="failed", error=str(error))
        finally:
            try:
                pdf_path.unlink(missing_ok=True)
            except OSError:
                logger.exception("Could not remove temporary PDF for Docling job %s", job_id)
            finally:
                _worker_slot.release()
