import importlib.util
import logging
import tempfile
from pathlib import Path

from flask import Blueprint, jsonify, request

from services.docling_service import DoclingBusyError, DoclingService
from utils.validators import validate_file

logger = logging.getLogger(__name__)
docling_bp = Blueprint('docling', __name__)


@docling_bp.route('/docling/extract', methods=['POST'])
def start_docling_extraction():
    """Start local Docling extraction for an uploaded PDF."""
    if importlib.util.find_spec('docling') is None:
        return jsonify({
            "success": False,
            "message": (
                "Docling is not installed in this backend environment. "
                "Install it with `pip install -r requirements-docling.txt`, "
                "then restart the backend."
            )
        }), 503

    uploaded_file = request.files.get('file')
    if uploaded_file is None or not uploaded_file.filename:
        return jsonify({"success": False, "message": "No PDF file was provided."}), 400

    is_valid, error_message = validate_file(uploaded_file)
    if not is_valid:
        status_code = 413 if "exceed" in error_message else 400
        return jsonify({"success": False, "message": error_message}), status_code

    signature = uploaded_file.stream.read(5)
    uploaded_file.stream.seek(0)
    if signature != b'%PDF-':
        return jsonify({"success": False, "message": "The uploaded file is not a valid PDF."}), 400

    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as temp_file:
            uploaded_file.save(temp_file)
            temp_path = Path(temp_file.name)
        job_id = DoclingService.start_job(temp_path)
        return jsonify({
            "success": True,
            "message": "Local Docling extraction started.",
            "data": {"job_id": job_id}
        }), 202
    except DoclingBusyError as error:
        if temp_path is not None:
            temp_path.unlink(missing_ok=True)
        return jsonify({"success": False, "message": str(error)}), 429
    except Exception:
        if temp_path is not None:
            temp_path.unlink(missing_ok=True)
        logger.exception("Failed to start local Docling extraction")
        return jsonify({
            "success": False,
            "message": "Could not start local Docling extraction."
        }), 500


@docling_bp.route('/docling/status/<job_id>', methods=['GET'])
def get_docling_status(job_id):
    """Return the status or result of a local Docling extraction."""
    job = DoclingService.get_job(job_id)
    if job is None:
        return jsonify({"success": False, "message": "Docling job not found."}), 404
    return jsonify({"success": True, "data": job}), 200
