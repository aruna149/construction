import requests, time
payload = {'document_id': 'df1b1b8f-5052-4b3a-839b-c79737516d5b.pdf'}
start = requests.post('http://127.0.0.1:5000/api/analysis/start', json=payload, timeout=30)
print('START', start.status_code, start.text)
job_id = start.json()['data']['job_id']
for i in range(20):
    status = requests.get(f'http://127.0.0.1:5000/api/analysis/status/{job_id}', timeout=30)
    job = status.json()['data']
    print('STATUS', i, job['status'], job['progress'], 'pages=', job.get('total_pages'))
    if job['status'] in ('completed', 'failed'):
        break
    time.sleep(1)
result = requests.get('http://127.0.0.1:5000/api/analysis/results/df1b1b8f-5052-4b3a-839b-c79737516d5b.pdf', timeout=30)
print('RESULT', result.status_code)
print(result.text[:1200])
