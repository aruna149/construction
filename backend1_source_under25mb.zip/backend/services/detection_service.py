import uuid
import threading
import logging
from pathlib import Path
from typing import Dict, Any, Optional
from config import Config
from services.image_converter import ImageConverter
from services.object_detector import ObjectDetector
from services.object_service import ObjectService

logger = logging.getLogger(__name__)

# Global in-memory stores for background jobs and persistent documents
jobs_store: Dict[str, Dict[str, Any]] = {}
results_store: Dict[str, Dict[str, Any]] = {}
lock = threading.Lock()

class DetectionService:
    """Service to manage background threads for PDF page extraction and object detection."""
    
    @staticmethod
    def start_analysis(document_id: str) -> str:
        """Create a new job and spawn a thread to run the analysis in the background.
        
        Args:
            document_id: The stored name of the PDF (e.g., '3f92bb2a-acde.pdf').
            
        Returns:
            str: The generated job_id.
        """
        job_id = str(uuid.uuid4())
        
        with lock:
            jobs_store[job_id] = {
                "job_id": job_id,
                "document_id": document_id,
                "status": "pending",
                "progress": 0,
                "total_pages": 0,
                "current_page": 0,
                "results": [],
                "error": None
            }
            
        # Spawn background processing thread
        thread = threading.Thread(
            target=DetectionService._run_analysis,
            args=(job_id, document_id),
            daemon=True
        )
        thread.start()
        
        logger.info(f"Spawned background analysis job {job_id} for document: {document_id}")
        return job_id

    @staticmethod
    def get_job_status(job_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve current progress state of a background job."""
        with lock:
            return jobs_store.get(job_id)

    @staticmethod
    def get_document_results(document_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve cached analysis findings for an analyzed document."""
        with lock:
            return results_store.get(document_id)

    @staticmethod
    def _run_analysis(job_id: str, document_id: str) -> None:
        """Core execution thread loop: PDF Page Conversion -> Template Scanning."""
        logger.info(f"Starting job {job_id} thread execution...")
        
        # 1. Update job to running
        with lock:
            if job_id in jobs_store:
                jobs_store[job_id]["status"] = "running"
                jobs_store[job_id]["progress"] = 5
                
        try:
            # 2. Resolve PDF Paths
            pdf_path = Path(Config.BASE_DIR) / 'uploads' / 'pdf' / document_id
            if not pdf_path.exists():
                raise FileNotFoundError(f"PDF document not found: {pdf_path}")
                
            # Get document folder name (remove .pdf extension)
            doc_folder_name = document_id.rsplit('.', 1)[0]
            
            # 3. Render pages to PNG (reuses pre-rendered ones or waits for background thread to finish)
            logger.info(f"Job {job_id}: Preparing page PNGs...")
            page_paths = ImageConverter.convert_pdf_to_pngs(str(pdf_path), doc_folder_name)
            
            if not page_paths:
                raise ValueError("PDF page extraction failed or returned 0 pages.")
                
            total_pages = len(page_paths)
            with lock:
                if job_id in jobs_store:
                    jobs_store[job_id]["total_pages"] = total_pages
                    jobs_store[job_id]["progress"] = 20
                    
            # 4. Fetch Active Templates from SQLite
            logger.info(f"Job {job_id}: Fetch active template objects...")
            active_objects = ObjectService.get_all(status_filter='active')
            
            if not active_objects:
                logger.warning(f"Job {job_id}: No active objects found in the database. Scan completed empty.")
                with lock:
                    if job_id in jobs_store:
                        jobs_store[job_id]["status"] = "completed"
                        jobs_store[job_id]["progress"] = 100
                        
                # Persist empty results
                with lock:
                    results_store[document_id] = {
                        "document_id": document_id,
                        "pages": total_pages,
                        "detections": []
                    }
                return

            # 5. Scan each page
            all_detections = []
            for idx, relative_page_path in enumerate(page_paths):
                page_num = idx + 1
                
                # A. Scan page for dynamic custom snippets (Chamfer)
                page_detections = ObjectDetector.detect_objects(
                    page_image_path=relative_page_path,
                    active_objects=active_objects,
                    page_number=page_num
                )
                all_detections.extend(page_detections)
                
                # Update progress page by page
                # Range 20% to 95%
                progress_step = 20 + int((page_num / total_pages) * 75)
                with lock:
                    if job_id in jobs_store:
                        jobs_store[job_id]["current_page"] = page_num
                        jobs_store[job_id]["progress"] = progress_step
                        
            # 6. Finalize Job
            logger.info(f"Job {job_id} finished. Found {len(all_detections)} objects across {total_pages} pages.")
            
            with lock:
                if job_id in jobs_store:
                    jobs_store[job_id]["status"] = "completed"
                    jobs_store[job_id]["progress"] = 100
                    jobs_store[job_id]["results"] = all_detections
                    
            # Save to persistent document results
            with lock:
                results_store[document_id] = {
                    "document_id": document_id,
                    "pages": total_pages,
                    "detections": all_detections
                }
                
        except Exception as e:
            logger.exception(f"Exception inside analysis job {job_id} thread execution")
            err_msg = str(e)
            with lock:
                if job_id in jobs_store:
                    jobs_store[job_id]["status"] = "failed"
                    jobs_store[job_id]["error"] = err_msg
