import requests, time
payload = {'document_id': 'df1b1b8f-5052-4b3a-839b-c79737516d5b.pdf'}
start = requests.post('http://127.0.0.1:5000/api/analysis/start', json=payload, timeout=30)
job_id = start.json()['data']['job_id']
print('JOB', job_id)
for i in range(90):
    status = requests.get(f'http://127.0.0.1:5000/api/analysis/status/{job_id}', timeout=30)
    job = status.json()['data']
    print('STATUS', i, job['status'], job['progress'], 'pages=', job.get('total_pages'))
    if job['status'] in ('completed', 'failed'):
        break
    time.sleep(1)
result = requests.get('http://127.0.0.1:5000/api/analysis/results/df1b1b8f-5052-4b3a-839b-c79737516d5b.pdf', timeout=30)
print('RESULT_STATUS', result.status_code)
print(result.text[:2000])
